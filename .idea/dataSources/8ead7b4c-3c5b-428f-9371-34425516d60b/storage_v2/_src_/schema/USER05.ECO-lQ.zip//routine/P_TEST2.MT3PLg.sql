create procedure p_test2
(name in varchar2,
su in number
)
is
begin
dbms_output.put_line(name||'님의 점수는'||su||'점 입니다.');
end;
/

