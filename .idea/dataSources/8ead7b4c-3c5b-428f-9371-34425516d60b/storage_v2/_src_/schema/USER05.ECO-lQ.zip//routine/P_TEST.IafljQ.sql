create procedure p_test
is
begin
dbms_output.put_line('oracle 시험 합격');
end;
/

