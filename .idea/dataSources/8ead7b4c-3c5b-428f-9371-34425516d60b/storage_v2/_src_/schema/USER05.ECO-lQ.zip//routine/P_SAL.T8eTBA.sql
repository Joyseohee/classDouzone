create procedure p_sal(name in varchar2)
is
begin
dbms_output.put_line(name||'oracle 시험 합격');
end;
/

