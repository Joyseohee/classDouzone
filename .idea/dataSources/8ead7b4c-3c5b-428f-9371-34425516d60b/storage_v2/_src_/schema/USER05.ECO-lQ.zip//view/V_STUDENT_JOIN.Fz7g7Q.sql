create view V_STUDENT_JOIN as
select p.profno,p.name as "교수 이름",p.position, s.studno, s.name as "학생 이름",
s.grade,d.dname
from professor p
inner join student s
on p.deptno=s.deptno1
inner join department d
on d.deptno = s.deptno1
/

