create view V_STUDENT_JOIN as
select p.profno 교수번호, p.name 이름, p.position 교수직급, s.studno 학번, s.name 학생이름, s.grade 학년, d.dname 학과명, p.deptno 학과번호 
    from professor p join student s
    on p.profno = s.profno join department d
    on s.deptno1 = d.deptno
/

