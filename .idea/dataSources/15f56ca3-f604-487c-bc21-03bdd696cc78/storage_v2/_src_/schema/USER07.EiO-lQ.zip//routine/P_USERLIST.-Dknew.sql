create PROCEDURE p_userlist(      -- 프로시저 생성 
    id in userlist.id%Type := 'kingsmile',
    name in userlist.name%TYPE default '도연이',
    age in userlist.age%type := 10,
    addr in userlist.addr%type := null
) 
is
begin
    insert into userlist values(id, name, age, addr);
    DBMS_OUTPUT.PUT_LINE('insert 정보는 : ' ||id||' ' ||name||' ' ||age||' '||addr );
end;
/

