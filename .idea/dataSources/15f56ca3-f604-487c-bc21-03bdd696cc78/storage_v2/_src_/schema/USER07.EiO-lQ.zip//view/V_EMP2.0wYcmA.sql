create view V_EMP2 as
select max(sal) 최대급여, min(sal) 최소급여, round(avg(sal), 3) 평균급여
    from emp
/

