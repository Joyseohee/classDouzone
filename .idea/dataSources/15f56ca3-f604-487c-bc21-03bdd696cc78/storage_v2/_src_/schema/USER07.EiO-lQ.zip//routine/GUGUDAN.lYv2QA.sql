create procedure gugudan (vdan in NUMBER)
is
BEGIN
    for i in 1..9 loop
        DBMS_OUTPUT.PUT_LINE (vdan || '*' || i || '= ' || vdan * i);
    END LOOP;
END;
/

