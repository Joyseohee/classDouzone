create PROCEDURE p_test
(
    name in varchar2,
    su in number
)
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE(NAME||'님의 점수는 : '||su);
END;
/

