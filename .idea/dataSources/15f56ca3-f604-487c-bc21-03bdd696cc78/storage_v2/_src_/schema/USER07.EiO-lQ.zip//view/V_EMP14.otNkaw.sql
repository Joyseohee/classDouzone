create view V_EMP14 as
select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO"from emp
    where job not in('MANAGER','manager') and sal >= 3000
/

