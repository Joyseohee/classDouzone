create procedure p_out( x in out number )
as
begin
    dbms_output.put_line( 'x = ' || x );
    x := 5;
end;
/

