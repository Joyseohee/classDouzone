create procedure danpro(
    dan number(1) := 3;
)
is    
    dan2 number(1) := 1;
begin
    while dan2 < 10 loop
        DBMS_OUTPUT.PUT_LINE(dan||' * '||dan2||' = '||dan * dan2);
        dan2 := dan2 + 1;
    end loop;
end;
/

