create PROCEDURE p_MSG
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE('오늘 뭐 먹지?');
END;

EXECUTE P_MSG; -- 프로시저 호출
------------------------------------------
CREATE OR REPLACE PROCEDURE p_MSG(NAME IN VARCHAR2)
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE(NAME||'! 오늘 뭐 먹지?');
END;

EXECUTE P_MSG('도연'); -- 프로시저 호출
------------------------------------------
CREATE OR REPLACE PROCEDURE p_test
(
    name in varchar2,
    su in number
)
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE(NAME||'님의 점수는 : '||su);
END;

EXECUTE P_test('도연', 99); -- 프로시저 호출
EXECUTE P_test('도연', );
-------------------------------------------------------
select * from userlist;
drop table userlist;
create table userlist (
    id varchar2(10),
    name varchar2(20),
    age number,
    addr varchar2(50)
);
desc userlist;

create or replace PROCEDURE p_userlist(      -- 프로시저 생성 
    id in userlist.id%Type := 'kingsmile',
    name in userlist.name%TYPE default '도연이',
    age in userlist.age%type := 10,
    addr in userlist.addr%type := null
) 
is
begin
    insert into userlist values(id, name, age, addr);
    DBMS_OUTPUT.PUT_LINE('insert 정보는 : ' ||id||' ' ||name||' ' ||age||' '||addr );
end;
-- 프로시저 실행문 -----------
EXEC P_USERLIST('YUNA', '김연아', 30, '군포');
EXEC P_USERLIST();
EXEC P_USERLIST(ID => '박보검', AGE => 33);
-----------

select * from userlist;

SELECT*
    FROM user_objects
    WHERE LOWER(OBJECT_TYPE) = 'PROCEDURE';
-----------
create or replace PROCEDURE p_userlist(      -- 프로시저 생성 
    id in userlist.id%Type := 'kingsmile',
    name in userlist.name%TYPE default '도연이',
    age in userlist.age%type := 10,
    addr in userlist.addr%type := null
) 
is
begin
    insert into userlist values(id, name, age, addr);
    DBMS_OUTPUT.PUT_LINE('insert 정보는 : ' ||id||' ' ||name||' ' ||age||' '||addr );
end;
-- 프로시저 실행문 -----------
EXEC P_USERLIST('YUNA', '김연아', 30, '군포');
EXEC P_USERLIST();
EXEC P_USERLIST(ID => '박보검', AGE => 33);

-------------------
Create or replace procedure p_sal
is
    v_salary number := 0;
    v_dept_id number := 0;
begin
    v_dept_id := round(dbms_random.value(10, 120), -1);
    DBMS_OUTPUT.PUT_LINE('값은?' ||v_dept_id);
    select sal into v_salary from emp where deptno = v_dept_id and rownum = 1;
    DBMS_OUTPUT.PUT_LINE(v_salary);

    if v_salary between 1 and 3000 then
        DBMS_OUTPUT.PUT_LINE('보수 적음');
    ELSIF v_salary between 3001 and 6000 then
        DBMS_OUTPUT.PUT_LINE('시세에 맞춰줌');
    ELSIF v_salary between 6001 and 9000 then
        DBMS_OUTPUT.PUT_LINE('보수 높음');
    else 
        DBMS_OUTPUT.PUT_LINE('보수 매우 높음');
    end if;
end;

exec p_sal;
/

