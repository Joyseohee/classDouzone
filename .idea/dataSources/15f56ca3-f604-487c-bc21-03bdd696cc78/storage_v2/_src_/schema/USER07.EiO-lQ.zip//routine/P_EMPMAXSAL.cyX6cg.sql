create procedure p_empmaxsal
is
    v_emprow emp%rowtype;
begin
    for i in 1..5 loop
        select * into v_emprow
            from ( select * 
                from (select * from emp order by sal desc)
                    where rownum <= i order by sal, ename)
            where rownum = 1 order by sal asc;
            dbms_output.put_line(v_emprow.empno ||' '||v_emprow.ename||' '||v_emprow.sal);
    end loop;
end;
/

