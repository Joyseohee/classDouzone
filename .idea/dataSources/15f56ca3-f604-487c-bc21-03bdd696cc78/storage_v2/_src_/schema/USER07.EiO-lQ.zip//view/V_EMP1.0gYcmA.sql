create view V_EMP1 as
select job 직위, ename 이름, sal 월급, deptno 부서
    from emp
    where deptno = 30
/

