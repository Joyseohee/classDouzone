create procedure p_join
is
    v_join professor%rowtype;
begin
    select  p.PROFNO, p.name, p.position, s.studno, s.name, s.grade, d.dname
        from professor p  join  student s  
        on p.PROFNO = s.PROFNO;
end;
/

