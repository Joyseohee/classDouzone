create view V_EMP_SAL as
select job 직위, ename 사원이름, sal 급여
    from emp
    where deptno = 30 and sal > 2000
/

