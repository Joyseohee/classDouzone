create procedure p_outTest(
    NAME OUT VARCHAR2, AGE OUT NUMBER
)
IS 
BEGIN
    NAME := '이나영';
    AGE := 20;
    DBMS_OUTPUT.PUT_LINE('OUT을 이용한 프로시져 완료');
END;
/

