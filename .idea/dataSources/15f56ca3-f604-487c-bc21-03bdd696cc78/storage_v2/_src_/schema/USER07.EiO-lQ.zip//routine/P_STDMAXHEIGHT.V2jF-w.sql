create PROCEDURE P_STDMAXHEIGHT
is
    V_STDROW STUDENT%rowtype;
begin
    for i in 1..35 loop
        select * into v_STDROW
            from (select *
                from (select * from STUDENT order by HEIGHT desc)
                    where rownum <= i order by HEIGHT)
            where rownum = 1 order by HEIGHT DESC;
         dbms_output.put_line(v_STDROW.STUDNO||' '||v_STDROW.name||' '||v_STDROW.HEIGHT);
    end loop;
end;
/

