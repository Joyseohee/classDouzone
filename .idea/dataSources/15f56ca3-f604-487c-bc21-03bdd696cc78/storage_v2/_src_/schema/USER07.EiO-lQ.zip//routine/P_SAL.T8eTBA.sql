create procedure p_sal
is
    v_salary number := 0;
    v_dept_id number := 0;
begin
    v_dept_id := round(dbms_random.value(10, 30), -1);
    DBMS_OUTPUT.PUT_LINE('값은?' ||v_dept_id);
    select sal into v_salary from emp where deptno = v_dept_id or rownum = 1;
    DBMS_OUTPUT.PUT_LINE(v_salary);

    if v_salary between 1 and 500 then
        DBMS_OUTPUT.PUT_LINE('보수 적음');
    ELSIF v_salary between 501 and 700 then
        DBMS_OUTPUT.PUT_LINE('시세에 맞춰줌');
    ELSIF v_salary between 701 and 900 then
        DBMS_OUTPUT.PUT_LINE('보수 높음');
    else 
        DBMS_OUTPUT.PUT_LINE('보수 매우 높음');
    end if;
end;
/

